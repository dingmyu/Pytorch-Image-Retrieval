from django.shortcuts import render
from datetime import datetime
import os,sys
def index(request): 
    context          = {}
    return render(request, 'index.html', context)
def res(request):
    if request.method == 'POST':
        res_path = '/var/www/html/img/'
        upload_path = '/home/yuqi_huo/hyq/HelloWorld/HelloWorld/upload'
        img=request.FILES.get('img')
        upload_file = upload_path + '/' + img.name + '-' + datetime.now().isoformat()
        f=open(upload_file,'wb')
        for line in img.chunks():
            f.write(line)
        f.close()
        #cmd = 'sudo cp ' + upload_file + ' ' + res_path + '4.jpg'
        cmd = 'python /disks/sdb/mingyu_ding/pytorch_deephash/img_search.py --querypath ' + upload_file
        #cmd = 'python /home/yuqi_huo/a.py'
        os.system(cmd)
        context          = {}
#    context['img_url'] = 'http://localhost:6175/html/img/test.jpg'
        return render(request, 'res.html', context)
